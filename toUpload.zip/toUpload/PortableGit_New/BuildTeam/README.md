# BuildTeam
Repository to keep .txt with update links and scripts
